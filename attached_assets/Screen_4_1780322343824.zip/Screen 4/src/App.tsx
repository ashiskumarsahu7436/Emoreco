import { useEffect } from "react";
import {
  ArrowRight,
  AudioLines,
  Clock,
  Eye,
  Folder,
  Home,
  Lock,
  Mail,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function App() {
  return (
    <div>
      <div className="bg-zinc-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <header className="sticky z-50 backdrop-blur-md bg-zinc-900/80 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid top-0 w-full">
          <div className="flex px-8 justify-between items-center w-full h-16">
            <div className="flex items-center gap-2">
              <div className="size-8 rounded-lg bg-[#155dfc] flex justify-center items-center">
                <AudioLines className="size-5 text-[#1c398e]" />
              </div>
              <span className="font-bold text-lg leading-7 tracking-tight">
                EMORECO
              </span>
            </div>
            <nav className="flex items-center gap-1">
              <Button variant="ghost" className="text-neutral-50 px-4 gap-2">
                <Home className="size-4" />
                Dashboard
              </Button>
              <Button variant="ghost" className="text-[#9f9fa9] px-4 gap-2">
                <Folder className="size-4" />
                Spaces
              </Button>
              <Button variant="ghost" className="text-[#9f9fa9] px-4 gap-2">
                <Clock className="size-4" />
                History
              </Button>
            </nav>
            <div className="flex items-center gap-2">
              <Button variant="ghost" className="text-[#9f9fa9] px-4">
                Sign In
              </Button>
              <Button className="bg-[#155dfc] text-[#1c398e] px-4">
                Get Started
              </Button>
            </div>
          </div>
        </header>
        <main className="flex items-stretch w-full">
          <div className="relative w-1/2 hidden overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1729161769741-e7bbb82abc84?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMHNvdW5kJTIwd2F2ZSUyMGF1ZGlvJTIwdmlzdWFsaXphdGlvbiUyMGRhcmslMjBibHVlfGVufDF8MXx8fDE3ODAyOTUyMjd8MA&ixlib=rb-4.1.0&q=80&w=400"
              alt="Sound wave visualization"
              className="object-cover absolute inset-0 w-full h-full"
              data-photoid="dFiMTeicQ-Y"
              data-authorname="Pawel Czerwinski"
              data-authorurl="https://unsplash.com/@pawel_czerwinski"
              data-blurhash="L11y|EQ,Q,bbL#pIo#f7R4VtkXoz"
            />
            <div className="bg-[linear-gradient(to_top,oklch(0.141_0.005_285.823)_5%,oklch(0.141_0.005_285.823/.55)_45%,transparent_100%)] absolute inset-0" />
            <div className="relative z-10 flex p-12 flex-col justify-end h-full">
              <div className="inline-flex backdrop-blur-sm rounded-full bg-zinc-900/60 text-sm leading-5 border-white/10 border-1 border-solid mb-6 px-4 py-1.5 items-center gap-2 w-fit">
                <Sparkles className="size-4 text-[#155dfc]" />
                <span className="text-[#9f9fa9]">
                  AI-Powered Emotion Recognition
                </span>
              </div>
              <h2 className="max-w-md leading-tight font-bold text-4xl leading-10 tracking-tight">
                Welcome back to your emotional insights.
              </h2>
              <p className="max-w-md text-[#9f9fa9] text-base leading-6 mt-4">
                Pick up right where you left off — your spaces, history, and
                analyses are waiting.
              </p>
              <div className="flex mt-8 items-center gap-8">
                <div>
                  <p className="font-bold text-2xl leading-8">98%</p>
                  <p className="text-[#9f9fa9] text-sm leading-5">Accuracy</p>
                </div>
                <div className="bg-white/10 w-px h-10" />
                <div>
                  <p className="font-bold text-2xl leading-8">12+</p>
                  <p className="text-[#9f9fa9] text-sm leading-5">Emotions</p>
                </div>
                <div className="bg-white/10 w-px h-10" />
                <div>
                  <p className="font-bold text-2xl leading-8">40+</p>
                  <p className="text-[#9f9fa9] text-sm leading-5">Languages</p>
                </div>
              </div>
            </div>
          </div>
          <div className="flex p-8 justify-center items-center w-full">
            <Card className="max-w-md bg-zinc-900 border-white/10 border-1 border-solid p-8 gap-6 w-full">
              <CardHeader className="p-0 gap-2">
                <CardTitle className="font-bold text-2xl leading-8 tracking-tight">
                  Sign in to EMORECO
                </CardTitle>
                <CardDescription className="text-[#9f9fa9]">
                  Enter your credentials to access your dashboard.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <Button
                  variant="outline"
                  className="bg-zinc-800/40 text-neutral-50 border-white/10 border-1 border-solid gap-2 w-full"
                >
                  <svg
                    className="size-4"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill="#4285F4"
                      d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47a5.53 5.53 0 0 1-2.4 3.63v3h3.86c2.26-2.09 3.56-5.17 3.56-8.87z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09A11.99 11.99 0 0 0 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.27 14.29a7.18 7.18 0 0 1 0-4.58V6.62H1.29a12 12 0 0 0 0 10.76l3.98-3.09z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.69 1.29 6.62l3.98 3.09C6.22 6.86 8.87 4.75 12 4.75z"
                    />
                  </svg>
                  Continue with Google
                </Button>
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 flex-1 h-px" />
                  <span className="text-[#9f9fa9] text-xs leading-4">
                    or continue with email
                  </span>
                  <div className="bg-white/10 flex-1 h-px" />
                </div>
                <div className="flex flex-col gap-2">
                  <Label
                    htmlFor="email"
                    className="font-medium text-sm leading-5"
                  >
                    Email address
                  </Label>
                  <div className="relative">
                    <Mail className="top-1/2 size-4 -translate-y-1/2 text-[#9f9fa9] absolute left-3" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      className="bg-zinc-800/40 border-white/10 border-1 border-solid pl-9"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <Label
                      htmlFor="password"
                      className="font-medium text-sm leading-5"
                    >
                      Password
                    </Label>
                    <a
                      className="font-medium text-[#155dfc] text-sm leading-5"
                      href="#"
                    >
                      Forgot password?
                    </a>
                  </div>
                  <div className="relative">
                    <Lock className="top-1/2 size-4 -translate-y-1/2 text-[#9f9fa9] absolute left-3" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter your password"
                      className="bg-zinc-800/40 border-white/10 border-1 border-solid px-9"
                    />
                    <Eye className="top-1/2 size-4 -translate-y-1/2 cursor-pointer text-[#9f9fa9] absolute right-3" />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="remember"
                    className="border-white/10 border-1 border-solid"
                  />
                  <Label
                    htmlFor="remember"
                    className="font-normal text-[#9f9fa9] text-sm leading-5"
                  >
                    Remember me for 30 days
                  </Label>
                </div>
              </CardContent>
              <CardFooter className="flex p-0 flex-col gap-4">
                <Button className="bg-[#155dfc] text-[#1c398e] gap-2 w-full">
                  Sign in
                  <ArrowRight className="size-4" />
                </Button>
                <p className="text-center text-[#9f9fa9] text-sm leading-5">
                  Don't have an account?
                  <a className="font-medium text-[#155dfc] ml-1" href="#">
                    Create one
                  </a>
                </p>
              </CardFooter>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
