import { useEffect } from "react";
import {
  ArrowRight,
  AudioWaveform,
  BrainCircuit,
  Clock,
  Folder,
  Home,
  Mic,
  PlayCircle,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import { FallbackComponent } from "./CustomComponents";

export default function App() {
  return (
    <div>
      <div className="bg-zinc-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <header className="sticky z-50 backdrop-blur-md bg-zinc-900/80 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid top-0 w-full">
          <div className="max-w-[1140px] flex mx-auto px-12 justify-between items-center h-20">
            <div className="flex items-center gap-2">
              <div className="size-9 bg-gradient-to-br from-[oklch(0.7_0.15_200)] to-[oklch(0.546_0.245_262.881)] rounded-lg flex justify-center items-center">
                <AudioWaveform className="size-5 text-neutral-50" />
              </div>
              <span className="font-bold text-xl leading-7 tracking-tight">
                EMORECO
              </span>
            </div>
            <nav className="flex items-center gap-1">
              <Button variant="ghost" className="text-neutral-50 gap-2">
                <Home className="size-4" />
                Dashboard
              </Button>
              <Button variant="ghost" className="text-[#9f9fa9] gap-2">
                <Folder className="size-4" />
                Spaces
              </Button>
              <Button variant="ghost" className="text-[#9f9fa9] gap-2">
                <Clock className="size-4" />
                History
              </Button>
            </nav>
            <div className="flex items-center gap-2">
              <Button variant="ghost" className="text-neutral-50">
                Sign In
              </Button>
              <Button className="bg-[#155dfc] text-[#1c398e]">
                Get Started
              </Button>
            </div>
          </div>
        </header>
        <main className="max-w-[1140px] mx-auto p-12">
          <section className="relative rounded-3xl bg-zinc-900 border-white/10 border-1 border-solid overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1621947081720-86970823b77a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMHNvdW5kJTIwd2F2ZSUyMGF1ZGlvJTIwdmlzdWFsaXphdGlvbiUyMGRhcmslMjBibHVlfGVufDF8MHx8fDE3ODAyOTQ5MzN8MA&ixlib=rb-4.1.0&q=80&w=400"
              alt="Abstract sound wave"
              className="object-cover absolute inset-0 w-full h-full"
              data-photoid="knTKij60p3g"
              data-authorname="Angelo Abear"
              data-authorurl="https://unsplash.com/@angeloabear"
              data-blurhash="L309z}e~fafZf4f4fRf5aFfmfTfk"
            />
            <div className="bg-gradient-to-r from-background via-background/90 to-background/40 absolute inset-0" />
            <div className="relative flex p-12 flex-col items-start gap-6">
              <div className="inline-flex rounded-full bg-zinc-800/60 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-1.5 items-center gap-2">
                <Sparkles className="size-4 text-[oklch(0.696_0.17_162.48)]" />
                AI-Powered Emotion Recognition
              </div>
              <h1 className="max-w-2xl leading-tight font-bold text-5xl leading-12 tracking-tight">
                Understand the emotion behind every
                <span className="bg-gradient-to-r from-[oklch(0.7_0.15_200)] to-[oklch(0.546_0.245_262.881)] bg-clip-text text-transparent">
                  voice
                </span>
              </h1>
              <p className="max-w-xl text-[#9f9fa9] text-lg leading-7">
                Record or upload audio and let EMORECO transcribe, analyze, and
                reveal the emotional tone in seconds. Organize insights into
                spaces and track your history.
              </p>
              <div className="flex pt-2 items-center gap-4">
                <Button className="bg-[#155dfc] text-[#1c398e] gap-2">
                  <Mic className="size-4" />
                  Start Analyzing
                </Button>
                <Button
                  variant="outline"
                  className="bg-zinc-800/40 text-neutral-50 border-white/10 border-0 border-solid gap-2"
                >
                  <PlayCircle className="size-4" />
                  Watch Demo
                </Button>
              </div>
              <div className="flex pt-6 items-center gap-8">
                <div className="flex flex-col">
                  <span className="font-bold text-2xl leading-8">98%</span>
                  <span className="text-[#9f9fa9] text-sm leading-5">
                    Accuracy
                  </span>
                </div>
                <div className="bg-white/10 w-px h-10" />
                <div className="flex flex-col">
                  <span className="font-bold text-2xl leading-8">12+</span>
                  <span className="text-[#9f9fa9] text-sm leading-5">
                    Emotions
                  </span>
                </div>
                <div className="bg-white/10 w-px h-10" />
                <div className="flex flex-col">
                  <span className="font-bold text-2xl leading-8">40+</span>
                  <span className="text-[#9f9fa9] text-sm leading-5">
                    Languages
                  </span>
                </div>
              </div>
            </div>
          </section>
          <section className="mt-12">
            <div className="text-center flex mb-8 flex-col items-center gap-2">
              <h2 className="font-bold text-3xl leading-9 tracking-tight">
                Everything you need to decode emotion
              </h2>
              <p className="max-w-xl text-[#9f9fa9]">
                A complete toolkit to capture audio, analyze sentiment, and
                organize your findings.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <Card className="bg-zinc-900 border-white/10 border-0 border-solid p-6 gap-4">
                <CardHeader className="p-0 gap-2">
                  <div className="size-11 rounded-xl bg-zinc-800 flex justify-center items-center">
                    <Mic className="size-5 text-[oklch(0.696_0.17_162.48)]" />
                  </div>
                  <CardTitle className="text-lg leading-7">{`Record & Upload`}</CardTitle>
                </CardHeader>
                <CardContent className="p-0 gap-2">
                  <p className="text-[#9f9fa9] text-sm leading-5">
                    Capture audio live from your microphone or upload existing
                    files in any common format.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-zinc-900 border-white/10 border-0 border-solid p-6 gap-4">
                <CardHeader className="p-0 gap-2">
                  <div className="size-11 rounded-xl bg-zinc-800 flex justify-center items-center">
                    <BrainCircuit className="size-5 text-[oklch(0.769_0.188_70.08)]" />
                  </div>
                  <CardTitle className="text-lg leading-7">
                    Emotion Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0 gap-2">
                  <p className="text-[#9f9fa9] text-sm leading-5">
                    Get instant transcription plus a detailed breakdown of the
                    dominant emotional tones.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-zinc-900 border-white/10 border-0 border-solid p-6 gap-4">
                <CardHeader className="p-0 gap-2">
                  <div className="size-11 rounded-xl bg-zinc-800 flex justify-center items-center">
                    <Folder className="size-5 text-[oklch(0.627_0.265_303.9)]" />
                  </div>
                  <CardTitle className="text-lg leading-7">{`Spaces & History`}</CardTitle>
                </CardHeader>
                <CardContent className="p-0 gap-2">
                  <p className="text-[#9f9fa9] text-sm leading-5">
                    Organize analyses into spaces and revisit your full history
                    whenever you need it.
                  </p>
                </CardContent>
              </Card>
            </div>
          </section>
          <section className="mt-12">
            <Card className="relative bg-gradient-to-br from-card to-secondary/40 border-white/10 border-0 border-solid p-12 gap-4 overflow-hidden">
              <CardContent className="text-center flex p-0 flex-col items-center gap-6">
                <h2 className="max-w-xl font-bold text-3xl leading-9 tracking-tight">
                  Ready to hear what emotions are saying?
                </h2>
                <p className="max-w-lg text-[#9f9fa9]">
                  Create your free account and run your first analysis in under
                  a minute.
                </p>
                <Button className="bg-[#155dfc] text-[#1c398e] gap-2">
                  <ArrowRight className="size-4" />
                  Get Started Free
                </Button>
              </CardContent>
            </Card>
          </section>
        </main>
        <footer className="border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid">
          <div className="max-w-[1140px] flex mx-auto px-12 py-8 justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="size-7 bg-gradient-to-br from-[oklch(0.7_0.15_200)] to-[oklch(0.546_0.245_262.881)] rounded-lg flex justify-center items-center">
                <AudioWaveform className="size-4 text-neutral-50" />
              </div>
              <span className="font-semibold">EMORECO</span>
            </div>
            <p className="text-[#9f9fa9] text-sm leading-5">
              © 2025 EMORECO. All rights reserved.
            </p>
            <div className="text-[#9f9fa9] flex items-center gap-4">
              <FallbackComponent className="size-4" />
              <FallbackComponent className="size-4" />
              <FallbackComponent className="size-4" />
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
