# Screen 3

This is a code bundle for Screen 3. It's based on default Vite project. The original design is available at https://app.flowstep.ai/file?activeFileId=6ef6cfd0-e9ac-41ec-8a1c-a6340d309029.

## Running the code

Run `npm i` and `npm run setup` to install the dependencies.

Run `npm run dev` to start the development server.
