import { useEffect } from "react";
import {
  ArrowRight,
  AudioLines,
  Check,
  Clock,
  Eye,
  Folder,
  Home,
  Lock,
  Mail,
  Sparkles,
  User,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function App() {
  return (
    <div>
      <div className="bg-zinc-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <header className="sticky z-50 backdrop-blur-md bg-zinc-950/80 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-12 py-4 justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="size-9 rounded-lg bg-[#155dfc] flex justify-center items-center">
              <AudioLines className="size-5 text-[#1c398e]" />
            </div>
            <span className="font-bold text-lg leading-7 tracking-tight">
              EMORECO
            </span>
          </div>
          <nav className="flex items-center gap-1">
            <Button variant="ghost" className="text-[#9f9fa9] gap-2">
              <Home className="size-4" />
              Dashboard
            </Button>
            <Button variant="ghost" className="text-[#9f9fa9] gap-2">
              <Folder className="size-4" />
              Spaces
            </Button>
            <Button variant="ghost" className="text-[#9f9fa9] gap-2">
              <Clock className="size-4" />
              History
            </Button>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" className="font-medium text-sm leading-5">
              Sign In
            </Button>
            <Button className="bg-[#155dfc] text-[#1c398e]">Get Started</Button>
          </div>
        </header>
        <main className="min-h-[876px] flex w-full">
          <div className="relative w-1/2 hidden overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1734832358799-24f041be2ae7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxhdWRpbyUyMHNvdW5kJTIwd2F2ZXMlMjBkYXJrJTIwYWJzdHJhY3QlMjBibHVlfGVufDF8MXx8fDE3ODAyOTUxMzh8MA&ixlib=rb-4.1.0&q=80&w=1200"
              alt="Audio waves"
              className="size-full object-cover absolute inset-0"
              data-photoid="pTcr6zx0L3A"
              data-authorname="Karsten Winegeart"
              data-authorurl="https://unsplash.com/@_karsten"
              data-blurhash="LC5FXt.T.8%N.9.9%hx]%h%hx^t8"
            />
            <div className="bg-[linear-gradient(to_right,oklch(0.141_0.005_285.823/.55),oklch(0.141_0.005_285.823/.9))] absolute inset-0" />
            <div className="relative z-10 flex p-12 flex-col justify-between h-full">
              <div className="flex items-center gap-2">
                <div className="size-9 rounded-lg bg-[#155dfc] flex justify-center items-center">
                  <AudioLines className="size-5 text-[#1c398e]" />
                </div>
                <span className="font-bold text-lg leading-7 tracking-tight">
                  EMORECO
                </span>
              </div>
              <div className="flex flex-col gap-6">
                <div className="inline-flex backdrop-blur-sm rounded-full bg-zinc-900/60 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-1.5 items-center gap-2 w-fit">
                  <Sparkles className="size-4 text-[oklch(0.696_0.17_162.48)]" />
                  <span className="text-[#9f9fa9]">
                    AI-Powered Emotion Recognition
                  </span>
                </div>
                <h2 className="max-w-md leading-tight font-bold text-4xl leading-10 tracking-tight">
                  Decode the emotion behind every
                  <span className="text-[#155dfc]">voice</span>
                </h2>
                <p className="max-w-md leading-relaxed text-[#9f9fa9] text-base leading-6">
                  Join thousands using EMORECO to transcribe, analyze, and
                  understand the emotional tone of any audio in seconds.
                </p>
                <div className="flex pt-4 flex-col gap-4">
                  <div className="flex items-center gap-3">
                    <div className="size-8 bg-[oklch(0.696_0.17_162.48/.15)] rounded-full flex justify-center items-center">
                      <Check className="size-4 text-[oklch(0.696_0.17_162.48)]" />
                    </div>
                    <span className="text-[#9f9fa9] text-sm leading-5">
                      98% transcription accuracy
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="size-8 bg-[oklch(0.696_0.17_162.48/.15)] rounded-full flex justify-center items-center">
                      <Check className="size-4 text-[oklch(0.696_0.17_162.48)]" />
                    </div>
                    <span className="text-[#9f9fa9] text-sm leading-5">
                      Detect 12+ distinct emotions
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="size-8 bg-[oklch(0.696_0.17_162.48/.15)] rounded-full flex justify-center items-center">
                      <Check className="size-4 text-[oklch(0.696_0.17_162.48)]" />
                    </div>
                    <span className="text-[#9f9fa9] text-sm leading-5">
                      Support for 40+ languages
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-[#9f9fa9] text-xs leading-4">
                © 2025 EMORECO. All rights reserved.
              </p>
            </div>
          </div>
          <div className="flex px-8 py-12 justify-center items-center w-full">
            <Card className="max-w-md bg-zinc-900 border-white/10 border-1 border-solid p-8 gap-6 w-full">
              <CardHeader className="p-0 gap-2">
                <CardTitle className="font-bold text-2xl leading-8 tracking-tight">
                  Create your account
                </CardTitle>
                <CardDescription className="text-[#9f9fa9] text-sm leading-5">
                  Start analyzing emotions in under a minute. No credit card
                  required.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <Button
                  variant="outline"
                  className="bg-zinc-800/40 text-sm leading-5 border-white/10 border-1 border-solid gap-2 w-full"
                >
                  <svg
                    className="size-4"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill="#4285F4"
                      d="M23.52 12.27c0-.79-.07-1.54-.2-2.27H12v4.51h6.47a5.53 5.53 0 0 1-2.4 3.63v3h3.88c2.27-2.09 3.57-5.17 3.57-8.87z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.94-2.91l-3.88-3c-1.08.72-2.45 1.16-4.06 1.16-3.12 0-5.77-2.11-6.71-4.95H1.28v3.09A12 12 0 0 0 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.29 14.3a7.2 7.2 0 0 1 0-4.6V6.61H1.28a12 12 0 0 0 0 10.78l4.01-3.09z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.76 0 3.34.61 4.59 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0A12 12 0 0 0 1.28 6.61l4.01 3.09C6.23 6.86 8.88 4.75 12 4.75z"
                    />
                  </svg>
                  Continue with Google
                </Button>
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 flex-1 h-px" />
                  <span className="text-[#9f9fa9] text-xs leading-4">
                    or continue with email
                  </span>
                  <div className="bg-white/10 flex-1 h-px" />
                </div>
                <div className="flex flex-col gap-2">
                  <Label
                    htmlFor="name"
                    className="font-medium text-sm leading-5"
                  >
                    Full name
                  </Label>
                  <div className="relative">
                    <User className="top-1/2 size-4 -translate-y-1/2 text-[#9f9fa9] absolute left-3" />
                    <Input
                      id="name"
                      placeholder="Jane Doe"
                      className="bg-zinc-800/40 border-white/15 border-1 border-solid pl-9"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Label
                    htmlFor="email"
                    className="font-medium text-sm leading-5"
                  >
                    Email address
                  </Label>
                  <div className="relative">
                    <Mail className="top-1/2 size-4 -translate-y-1/2 text-[#9f9fa9] absolute left-3" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      className="bg-zinc-800/40 border-white/15 border-1 border-solid pl-9"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Label
                    htmlFor="password"
                    className="font-medium text-sm leading-5"
                  >
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="top-1/2 size-4 -translate-y-1/2 text-[#9f9fa9] absolute left-3" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="At least 8 characters"
                      className="bg-zinc-800/40 border-white/15 border-1 border-solid px-9"
                    />
                    <Eye className="top-1/2 size-4 -translate-y-1/2 cursor-pointer text-[#9f9fa9] absolute right-3" />
                  </div>
                </div>
                <div className="flex pt-1 items-start gap-2">
                  <Checkbox
                    id="terms"
                    className="border-white/15 border-1 border-solid mt-0.5"
                  />
                  <Label
                    htmlFor="terms"
                    className="leading-relaxed font-normal text-[#9f9fa9] text-xs leading-4"
                  >
                    I agree to the
                    <span className="text-[#155dfc]">Terms of Service</span>and
                    <span className="text-[#155dfc]">Privacy Policy</span>.
                  </Label>
                </div>
              </CardContent>
              <CardFooter className="flex p-0 flex-col gap-4">
                <Button className="bg-[#155dfc] text-[#1c398e] gap-2 w-full">
                  Create account
                  <ArrowRight className="size-4" />
                </Button>
                <p className="text-center text-[#9f9fa9] text-sm leading-5">
                  Already have an account?
                  <span className="cursor-pointer font-medium text-[#155dfc]">
                    Sign in
                  </span>
                </p>
              </CardFooter>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
